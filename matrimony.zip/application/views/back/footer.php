<!-- FOOTER -->
<!--===================================================-->
<footer id="footer">
	<p class="text-center">
		&#0169; <?=date("Y")?> <a href="<?=base_url()?>" target="_blank"><?=$this->system_name?></a>
		<span style="float: right;padding-right: 5px">Version 1.9</span>
	</p>

</footer>
<!--===================================================-->
<!-- END FOOTER -->
